export const icons: {
  name: string;
  bidirectional: boolean;
  category: string;
  animated: boolean;
}[];
