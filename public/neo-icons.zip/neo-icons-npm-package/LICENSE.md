Copyright 2022 Avaya Inc. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of these image files and .css software and associated documentation files (the "Image and Software"), the rights to use, copy, modify, merge, publish, distribute, sublicense, and to permit persons to whom the Image and Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Image and Software.

NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY’S PATENT RIGHTS ARE GRANTED BY THIS LICENSE. THE IMAGE AND SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE IMAGE AND SOFTWARE OR THE USE OR OTHER DEALINGS IN THE IMAGE AND SOFTWARE.
